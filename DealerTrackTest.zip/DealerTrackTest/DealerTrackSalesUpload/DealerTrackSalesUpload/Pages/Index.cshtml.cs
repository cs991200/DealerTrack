﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DealerTrackSalesUpload.Data.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DealerTrackSalesUpload.Data.Repositories;
using DealerTrackSalesUpload.Business;

namespace DealerTrackSalesUpload.Pages
{
    public class IndexModel : PageModel
    {
        
        private ISalesDataRepo repo;
        private ISalesFileProcessor saleFileProcessor;
        public  List<Exception> Exceptions = new List<Exception>();
        public List<Sale> Sales = new List<Sale>();
        public  string FileName = string.Empty;
        public IndexModel(ISalesDataRepo repo, ISalesFileProcessor saleFileProcessor)
        {
            this.repo = repo;
            this.saleFileProcessor = saleFileProcessor;
        }
        public void OnGet()
        {

        }

        public string IsVisible()
        {
            if(Sales.Count>0 && Exceptions.Count<=0)
            {
                 return string.Empty;
            }
            else
            {
                return "hidden";
            }

        }
        [HttpPost]
        public void OnPost(IFormFile file)
        {
            this.FileName = file.FileName;
            if(file==null)
            {
                return;
            }
            saleFileProcessor.Process(file);
            Exceptions = saleFileProcessor.GetExceptions();
            if (Exceptions.Count==0)
            {
                Sales = saleFileProcessor.GetSales();
                repo.Add(Sales);
                repo.GetMostFrequentlySoldVehicle(this.FileName);
            }
        }
    }
}
