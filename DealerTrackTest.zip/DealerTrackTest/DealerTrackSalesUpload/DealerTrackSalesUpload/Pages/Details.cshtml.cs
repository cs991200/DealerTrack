﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DealerTrackSalesUpload.Data.Entities;
using DealerTrackSalesUpload.Data.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DealerTrackSalesUpload.Pages
{
   
    public class DetailsModel : PageModel
    {
        public readonly string CurrencPrefix = "CAD";
        public List<Sale> Sales = new List<Sale>();
        public string MostFrequentlySoldVehicle = string.Empty;
        private ISalesDataRepo repo;
        public string FileName = string.Empty;
        public DetailsModel(ISalesDataRepo repo)
        {
            this.repo = repo;

        }

       
        public void OnGet(string fileName)
        {
            this.FileName = fileName;
            Sales= this.repo.GetSales(fileName).ToList<Sale>();
            MostFrequentlySoldVehicle = this.repo.GetMostFrequentlySoldVehicle(fileName);
            //Sales = repo.GetMostFrequentlySoldVehicle(fileName);
        }
    }
}