﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using DealerTrackSalesUpload.Data.Entities;

namespace DealerTrackSalesUpload.Data.Contexts
{
    public class SalesDBContext: DbContext
    {
        public SalesDBContext(DbContextOptions<SalesDBContext> contextOptions): base(contextOptions)
        {

        }
        public DbSet<Sale> Sales { get; set; }
    }
}
