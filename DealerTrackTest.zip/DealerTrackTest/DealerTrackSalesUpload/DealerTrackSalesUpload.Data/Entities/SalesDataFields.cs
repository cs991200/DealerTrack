﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DealerTrackSalesUpload.Data.Entities
{
    public enum SalesDataFields
    {
        DealNumber,
        CustomerName,
        DealershipName,
        Vehicle,
        Price,
        Date
    }
}
