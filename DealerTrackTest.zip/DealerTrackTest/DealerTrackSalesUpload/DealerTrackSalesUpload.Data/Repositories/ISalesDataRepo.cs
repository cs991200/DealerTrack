﻿using DealerTrackSalesUpload.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DealerTrackSalesUpload.Data.Repositories
{
    public interface ISalesDataRepo
    {
        System.Linq.IQueryable<Sale> GetSales(string fileName);
        string GetMostFrequentlySoldVehicle(string fileName);
        bool Update(List<Sale> sale);
        bool Add(List<Sale> sale);
    }
}
