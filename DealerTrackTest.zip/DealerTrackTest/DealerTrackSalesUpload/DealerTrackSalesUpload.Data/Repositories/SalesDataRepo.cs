﻿using System;
using System.Collections.Generic;
using System.Text;
using DealerTrackSalesUpload.Data.Contexts;
using DealerTrackSalesUpload.Data.Entities;
using System.Linq;

namespace DealerTrackSalesUpload.Data.Repositories
{
    public class SalesDataRepo : ISalesDataRepo
    {
        private readonly SalesDBContext context;

        public SalesDataRepo(SalesDBContext context)
        {
            this.context = context;
        }

        public string GetMostFrequentlySoldVehicle(string fileName)
        {
            //return  from s in  context.Sales  group 

            var groupResult = from s in context.Sales
                              group s by s.Vehicle into sls orderby sls.Count() 
                              descending select sls;

            var result = groupResult.FirstOrDefault();

            return result.Key;
        }




        public bool Add(List<Sale> sales)
        {
            foreach(var sale in sales)
            {
                context.Add(sale);
            }

            context.SaveChanges();
            return true;
        }

        public System.Linq.IQueryable<Sale> GetSales(string fileName)
        {
            return from s in context.Sales where s.FileName == fileName select s;
        }

        public bool Update(List<Sale> sale)
        {
            throw new NotImplementedException();
        }

        
    }
}
