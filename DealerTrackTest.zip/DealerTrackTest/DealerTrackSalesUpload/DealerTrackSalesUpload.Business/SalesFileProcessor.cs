﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using DealerTrackSalesUpload.Data.Entities;
using Microsoft.AspNetCore.Http;
using static Microsoft.AspNetCore.WebSockets.Internal.Constants;

namespace DealerTrackSalesUpload.Business
{
    public class SalesFileProcessor: ISalesFileProcessor
    {
        private List<Exception> Exceptions = new List<Exception>();
        private List<Sale> Sales = new List<Sale>();

        private Sale ProcessLine(int lineRecord, List<string> fields, string fileName)
        {
            Sale saleRecord = new Sale();
            try
            {
                saleRecord.DealNumber = ProcessFieldInt(SalesDataFields.DealNumber, fields);
                saleRecord.CustomerName = ProcessFieldString(SalesDataFields.CustomerName, fields);
                saleRecord.DealershipName = ProcessFieldString(SalesDataFields.DealershipName, fields);
                saleRecord.Vehicle = ProcessFieldString(SalesDataFields.Vehicle, fields);
                saleRecord.Price = ProcessFieldDecimal(SalesDataFields.Price, fields);
                saleRecord.Date = ProcessFieldDateTime(SalesDataFields.Date, fields);
                saleRecord.FileName = fileName;
            }
            catch (Exception ex)
            {
                throw new Exception("Line: " + lineRecord + " has invalid value." + ex.Message);
            }

            return saleRecord;
        }
        private string ProcessFieldString(SalesDataFields field, List<string> fields)
        {
            string returnVlue = default(string);
            try
            {
                returnVlue = fields[(int)field].Trim();
            }
            catch (Exception ex)
            {
                throw new Exception("Field: " + field + "has invalid value." + ex.Message);
            }
            return returnVlue;
        }
        private int ProcessFieldInt(SalesDataFields field, List<string> fields)
        {
            int returnVlue = default(int);
            try
            {
                returnVlue = (int)ParseValue<int>(fields[(int)field]);
            }
            catch (Exception ex)
            {
                throw new Exception("Field: " + field + "has invalid value." + ex.Message);
            }

            return returnVlue;
        }
        private decimal ProcessFieldDecimal(SalesDataFields field, List<string> fields)
        {
            decimal returnVlue = default(decimal);
            try
            {
                returnVlue = Helpers.ConvertValue.ToDecimal(fields[(int)field]);
            }
            catch (Exception ex)
            {
                throw new Exception("Field: " + field + " has invalid value." + ex.Message);
            }

            return returnVlue;
        }
        private DateTime ProcessFieldDateTime(SalesDataFields field, List<string> fields)
        {
            DateTime returnVlue = default(DateTime);
            try
            {
                returnVlue = (DateTime)ParseValue<DateTime>(fields[(int)field]);


            }
            catch (Exception ex)
            {
                throw new Exception("Field: " + field + "has invalid value." + ex.Message);
            }

            return returnVlue;
        }
        public T ParseValue<T>(string value)
        {
            return (T)TypeDescriptor.GetConverter(typeof(T)).ConvertFromString(value);
        }
        public void Process(IFormFile file)
        {
            Stream str = file.OpenReadStream();
            using (StreamReader streamReader = new StreamReader(str, Encoding.GetEncoding(1252)))
            {
                string line = String.Empty;
                int lineCount = 0;
                while ((line = streamReader.ReadLine()) != null)
                {
                    if (lineCount == 0)
                    {
                        //header skip it for now
                        //iplement header validation
                    }
                    else
                    {
                        List<string> fields = new List<string>();
                        //move regex to config file
                        MatchCollection matches = new Regex("((?<=\")[^\"]*(?=\"(,|$)+)|(?<=,|^)[^,\"]*(?=,|$))").Matches(line);

                        foreach (var match in matches)
                        {
                            fields.Add(match.ToString());
                        }
                        //move 6 to config file
                        if (fields.Count == 6)
                        {
                            try
                            {
                                var sale = ProcessLine(lineCount, fields, file.FileName);
                                Sales.Add(sale);
                            }
                            catch (Exception ex)
                            {
                                Exceptions.Add(ex);
                            }

                        }
                        else
                        {
                            Exceptions.Add(new Exception("Line: " + lineCount + " has invalid number of columns"));
                        }
                    }

                    System.Diagnostics.Debug.WriteLine(line);
                    lineCount++;
                }
            }
        }

        public List<Exception> GetExceptions()
        {
            return Exceptions;
        }

        public List<Sale> GetSales()
        {
            return Sales;
        }
    }
}
