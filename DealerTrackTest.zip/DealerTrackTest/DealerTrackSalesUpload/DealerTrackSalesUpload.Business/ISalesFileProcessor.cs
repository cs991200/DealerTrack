﻿using DealerTrackSalesUpload.Data.Entities;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace DealerTrackSalesUpload.Business
{
    public interface ISalesFileProcessor
    {
        void Process(IFormFile file);
        List<Exception> GetExceptions();
        List<Sale> GetSales();
    }
}
