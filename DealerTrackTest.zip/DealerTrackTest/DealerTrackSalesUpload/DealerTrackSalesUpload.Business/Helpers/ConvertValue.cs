﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DealerTrackSalesUpload.Business.Helpers
{
    public   class ConvertValue
    {
        public static int ToInt(string value)
        {
            return int.Parse(value.Trim());
        }

        public static Decimal ToDecimal(string value)
        {
            return Decimal.Parse(value.Trim());
        }
        public static DateTime ToDateTime(string value)
        {
            return DateTime.Parse(value.Trim());
        }
    }
}
